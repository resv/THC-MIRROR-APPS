Placeholder for safelists directory
